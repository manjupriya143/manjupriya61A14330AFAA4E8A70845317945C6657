def factorial(n):
    # Base case: If n is 0 or 1, return 1 (0! and 1! are both 1)
    if n == 0 or n == 1:
        return 1
    else:
        # Recursive case: n! = n * (n-1)!
        return n * factorial(n - 1)






